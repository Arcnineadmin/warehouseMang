-- AlterTable
ALTER TABLE `Attribute` MODIFY `attributeValue` LONGTEXT NOT NULL;
