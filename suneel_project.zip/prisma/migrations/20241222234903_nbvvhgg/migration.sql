-- AlterTable
ALTER TABLE `AbisisProduct` MODIFY `ean` VARCHAR(191) NULL;
