-- AlterTable
ALTER TABLE `AbisisAttributeList` MODIFY `value` LONGTEXT NOT NULL;
